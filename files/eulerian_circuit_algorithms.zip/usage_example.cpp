/*
 * An example of using the eulerian tour algorithms.
 *
 * Author: Brent Walther
 * Last Updated: Dec 27, 2015
 */

#include <iostream>
#include <fstream>
#include <string>

#include <boost/tokenizer.hpp>
#include <sys/time.h>

#include "euler_tour.cpp"

#define PRINT_DEBUG_STATEMENTS false

using namespace boost;

int main(int argc, char* argv[]) {
  typedef adjacency_list <vecS, vecS, undirectedS> UndirectedGraph;
  typedef graph_traits<UndirectedGraph>::vertex_descriptor Vertex;
  typedef graph_traits<UndirectedGraph>::vertex_iterator VertexIterator;
  typedef graph_traits<UndirectedGraph>::edge_descriptor GraphEdge;
  typedef property_map<UndirectedGraph, vertex_index_t>::type IndexMap;

  // construct graph and print out the list of edges
  UndirectedGraph g;
  int num_nodes = -1, count = 0;

  std::string line;
  while (getline(std::cin, line)) {
    char_separator<char> sep(" ");
    tokenizer<char_separator<char> > tokens(line, sep);
    if (count == 0) {
      int num_nodes = std::stoi(line);
      if (PRINT_DEBUG_STATEMENTS) {
        std::cout << "Building a graph with " << num_nodes << " vertices.\n";
      }
    } else {
      int e1 = -1, e2 = -1;
      for (const auto& token : tokens) {
        int val = std::stoi(token);
        if (e1 == -1) {
          e1 = val;
        } else {
          e2 = val;
        }
      }
      add_edge(e1, e2, g);
      if (PRINT_DEBUG_STATEMENTS) {
        std::cout << "Adding edge " << e1 << " -> " << e2 << "\n";
      }
    }
    count++;
  }

  IndexMap index = get(vertex_index, g);
  std::vector<GraphEdge> euler_circuit;
  compute_euler_circuit<UndirectedGraph>(g, euler_circuit);

  for (auto ei = euler_circuit.begin(); ei != euler_circuit.end(); ei++) {
    std::cout << index[source(*ei, g)] << " " << index[target(*ei, g)] << std::endl;
  }
  std::cout << std::endl;

  return 0;
}
