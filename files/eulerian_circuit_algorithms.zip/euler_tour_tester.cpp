/*
 * Code to read in a graph or generate a random eulerian
 * graph and then test the validity of the algorithms.
 *
 * Author: Brent Walther
 * Last Updated: Dec 27, 2015
 */

#include <iostream>
#include <fstream>
#include <string>

#include <boost/tokenizer.hpp>
#include <sys/time.h>

#include "euler_tour.cpp"

#define PRINT_GRAPH_EDGES false
#define PRINT_PATHS false

using namespace boost;

int main(int argc, char* argv[]) {
  int has_input_file = true;
  if (argc != 2) {
    std::cerr << "No filename to read in. Creating a random graph instead.\n";
    has_input_file = false;
  }

  typedef adjacency_list <vecS, vecS, undirectedS> UndirectedGraph;
  typedef graph_traits<UndirectedGraph>::vertex_descriptor Vertex;
  typedef graph_traits<UndirectedGraph>::vertex_iterator VertexIterator;
  typedef graph_traits<UndirectedGraph>::edge_descriptor GraphEdge;
  typedef property_map<UndirectedGraph, vertex_index_t>::type IndexMap;

  // construct graph and print out the list of edges
  UndirectedGraph g;

  typedef std::pair<int, int> Edge;
  std::vector<Edge> edgeVec;
  int num_nodes = -1;

  if (has_input_file) {
    std::ifstream myfile (argv[1]);
    if (!myfile.is_open()) {
      std::cerr << "Could not open file.\n";
      has_input_file = false;
    }

    int count = 0;

    std::string line;
    while (myfile.is_open() && getline(myfile,line)) {
      char_separator<char> sep(" ");
      tokenizer<char_separator<char> > tokens(line, sep);
      if (count == 0) {
        int num_nodes = std::stoi(line);
        if (PRINT_GRAPH_EDGES) {
          std::cout << "Building a graph with " << num_nodes << " vertices.\n";
        }
      } else {
        int e1 = -1, e2 = -1;
        for (const auto& token : tokens) {
          int val = std::stoi(token);
          if (e1 == -1) {
            e1 = val;
          } else {
            e2 = val;
          }
        }
        add_edge(e1, e2, g);
        if (PRINT_GRAPH_EDGES) {
          std::cout << "Adding edge " << e1 << " -> " << e2 << "\n";
        }
      }
      count++;
    }
    myfile.close();
  }
  /* else = no input file */
  else {
    int tmp;
    std::cout << "Specify the number of nodes in the random graph: ";
    std::cin >> tmp;
    srand(time(NULL));
    num_nodes = tmp;
    int num_edges = num_nodes * 4;

    for (int i = 0; i < num_edges; i++) {
      if (i < num_nodes) {
        int a = -1;
        do {
          a = rand() % num_nodes;
        } while (a == i);
        add_edge(i, a, g);
      } else {
        int a = rand() % num_nodes;;
        int b = -1;
        do {
          b = rand() % num_nodes;
        } while (a == b);
        if (edge(a, b, g).second == false && edge(b, a, g).second == false) {
          add_edge(a, b, g);
        }
      }
    }

    std::vector<Vertex> odd_vertices;
    VertexIterator vi, vi_end;
    for (tie(vi, vi_end) = vertices(g); vi != vi_end; ++vi) {
      typename graph_traits<UndirectedGraph>::out_edge_iterator ei, ei_end;
      int num_adjacent = 0;
      for (tie(ei, ei_end) = out_edges(*vi, g); ei != ei_end; ++ei) {
        num_adjacent++;
      }
      if (num_adjacent % 2 == 1) {
        odd_vertices.push_back(*vi);
      }
    }
    if (PRINT_GRAPH_EDGES) {
      std::cout << "num odd vertices that need a fix: " << odd_vertices.size() << std::endl;
    }
    std::vector<Vertex>::iterator v;
    int num = num_vertices(g);
    for (v = odd_vertices.begin(); v != odd_vertices.end(); v++) {
      add_edge(*v, num, g);
    }
  }

  IndexMap index = get(vertex_index, g);
  if (PRINT_GRAPH_EDGES) {
    std::cout << "edges(g) = ";
    graph_traits<UndirectedGraph>::edge_iterator ei, ei_end;
    for (boost::tie(ei, ei_end) = edges(g); ei != ei_end; ++ei) {
        std::cout << "[" << index[source(*ei, g)]
                  << "," << index[target(*ei, g)] << "], ";
    }
    std::cout << std::endl;
  }

  // check for the existence of both a euler tour and circuit
  struct timeval start, end;
  gettimeofday(&start, NULL);
  bool has_path = has_euler_path<UndirectedGraph>(g);
  gettimeofday(&end, NULL);
  long long elapsed_time =   (end.tv_sec * (unsigned int)1e6 +   end.tv_usec) -
                   (start.tv_sec * (unsigned int)1e6 + start.tv_usec);
  std::cout << "has euler path? " << (has_path ? "yes" : "no") << " in " << elapsed_time << " microseconds." << std::endl;
  gettimeofday(&start, NULL);
  bool has_circuit = has_euler_circuit<UndirectedGraph>(g);
  gettimeofday(&end, NULL);
  elapsed_time =   (end.tv_sec * (unsigned int)1e6 +   end.tv_usec) -
                   (start.tv_sec * (unsigned int)1e6 + start.tv_usec);
  std::cout << "has euler circuit? " << (has_circuit ? "yes" : "no") << " in " << elapsed_time << " microseconds." << std::endl;

  std::vector<GraphEdge> euler_path;
  gettimeofday(&start, NULL);
  compute_euler_path<UndirectedGraph>(g, euler_path);
  gettimeofday(&end, NULL);
  elapsed_time =   (end.tv_sec * (unsigned int)1e6 +   end.tv_usec) -
                   (start.tv_sec * (unsigned int)1e6 + start.tv_usec);
  std::cout << "euler path computation took " << elapsed_time << " microseconds" << std::endl;

  bool path_okay = euler_path.size() == num_edges(g);
  for (auto ei = euler_path.begin(); ei != euler_path.end(); ei++) {
    if (PRINT_PATHS) {
      std::cout << "(" << index[source(*ei, g)]
                      << "," << index[target(*ei, g)] << ") ";
    }
    if ((ei + 1) != euler_path.end()) {
      path_okay &= (target(*ei, g) == source(*(ei + 1), g));
    }
  }
  std::cout << "path okay? " << (path_okay ? "yes" : "no") << std::endl;

  std::vector<GraphEdge> euler_circuit;
  gettimeofday(&start, NULL);
  compute_euler_circuit<UndirectedGraph>(g, euler_circuit);
  gettimeofday(&end, NULL);
  elapsed_time =   (end.tv_sec * (unsigned int)1e6 +   end.tv_usec) -
                   (start.tv_sec * (unsigned int)1e6 + start.tv_usec);
  std::cout << "euler circuit computation took " << elapsed_time << " microseconds" << std::endl;

  bool circuit_okay = euler_circuit.size() == num_edges(g);
  for (auto ei = euler_circuit.begin(); ei != euler_circuit.end(); ei++) {
    if (PRINT_PATHS) {
      std::cout << "(" << index[source(*ei, g)]
                      << "," << index[target(*ei, g)] << ") ";
    }
    if ((ei + 1) == euler_circuit.end()) {
      circuit_okay &= (target(*ei, g) == source(*euler_circuit.begin(), g));
    } else {
      circuit_okay &= (target(*ei, g) == source(*(ei + 1), g));
    }
  }
  std::cout << "circuit okay? " << (circuit_okay ? "yes" : "no") << std::endl;

  bool path_passed = (has_path && path_okay);
  bool circuit_passed = (has_circuit && circuit_okay);
  std::cout << "path passed? " << (path_passed ? "yes." : "no.") << std::endl;
  std::cout << "circuit passed? " << (circuit_passed ? "yes." : "no.") << std::endl;

  return 0;
}
