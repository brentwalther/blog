/*
 * An example for using the Eulerian tour algorithm provided in
 * this zip package.
 *
 * Author: Brent Walther
 * Last Updated: Dec 27, 2015
 */

#include <boost/graph/adjacency_list.hpp>
#include <iostream>
#include "euler_tour.cpp"

using namespace boost;

int main() {
  typedef adjacency_list<vecS, vecS, undirectedS> UndirectedGraph;
  typedef property_map<UndirectedGraph, vertex_index_t>::type IndexMap;
  typedef graph_traits<UndirectedGraph>::edge_descriptor Edge;
  typedef std::pair<int, int> IntPair;

  enum { a, b, c, d, e, f, N };
  const char *name = "abcdef";
  IntPair edge_array[] = {
    IntPair(a, b), IntPair(b, c), IntPair(c, d), IntPair(d, a), IntPair(b, e), IntPair(e, c),
    IntPair(c, f), IntPair(f, b)
  };
  /*  6 0 1
      0 1
      1 2
      2 3
      3 0
      1 4
      4 2
      2 5
      5 1*/

  typedef graph_traits<UndirectedGraph>::vertices_size_type v_size_t;
  const int n_edges = sizeof(edge_array) / sizeof(IntPair);
  UndirectedGraph g(edge_array, edge_array + n_edges, v_size_t(N));

  bool has_circuit = has_euler_circuit<UndirectedGraph>(g);
  std::cout << "has euler circuit? " << (has_circuit ? "yes" : "no") << std::endl;

  std::vector<Edge> circuit_path;
  compute_euler_circuit<UndirectedGraph>(g, circuit_path);

  IndexMap index = get(vertex_index, g);
  std::cout << "Path of the euler circuit: " << std::endl;
  for (auto ei = circuit_path.begin(); ei != circuit_path.end(); ei++) {
    std::cout << "(" << name[index[source(*ei, g)]] << "," << name[index[target(*ei, g)]] << ") ";
  }
  std::cout << std::endl;

  return EXIT_SUCCESS;
}
