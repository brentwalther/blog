/*
 * Algorithms to test for the existence of and compute
 * Eulerian tours.
 *
 * Author: Brent Walther
 * Last Updated: Dec 27, 2015
 */

#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/depth_first_search.hpp>
#include <boost/graph/undirected_dfs.hpp>

using namespace boost;

class default_euler_tour_visitor {
public:
  virtual double tour_edge() = 0;
private:
  default_euler_tour_visitor() { }
};

template <typename Counter>
class dfs_odd_even_visitor : public default_dfs_visitor {
 public:
  dfs_odd_even_visitor(Counter counts) : counts(counts) { }

  template <typename Vertex, typename Graph>
  void finish_vertex(Vertex u, const Graph& g) const {
    if (counts[0] > 2) {
       // more than one odd vertex means an euler tour is not possible. return early
      return;
    }
    typename graph_traits<Graph>::edges_size_type num_edges = 0;
    typename graph_traits<Graph>::adjacency_iterator vi, vi_end, next;
    for (tie(vi, vi_end) = adjacent_vertices(u, g); vi != vi_end; vi++) {
      num_edges++;
    }
    if (num_edges % 2 == 1) {
      counts[0]++;
    }
  }

  template <typename Vertex, typename Graph>
  void start_vertex(Vertex u, const Graph& g) {
    if (counts[1] > 1) {
      // more than one disconnected component means an euler tour is impossible. return early
      return;
    }
    counts[1]++;
  }

 private:
  Counter counts;
};

template <typename Graph>
std::vector<int>
get_graph_counts(const Graph& G) {
  std::vector<int> counts(2);
  dfs_odd_even_visitor<int*> vis(&counts[0]);
  try {
    depth_first_search(G, visitor(vis));
  } catch (...) { /* early return */ }
  return counts;
}

template <typename Graph, typename Edge = typename graph_traits<Graph>::edge_descriptor>
void
compute_euler(const Graph& g, std::vector<Edge>& path, bool compute_circuit) {

  typedef typename graph_traits<Graph>::vertex_descriptor Vertex;
  typedef typename graph_traits<Graph>::vertex_iterator VertexIterator;

  Vertex start_vertex;
  VertexIterator vi, vi_end;
  //printf("coloring all nodes white\n");
  for (tie(vi, vi_end) = vertices(g), start_vertex = *vi; vi != vi_end; ++vi) {
    if (!compute_circuit) {
      typename graph_traits<Graph>::out_edge_iterator ei, ei_end;
      int num_adjacent = 0;
      for (tie(ei, ei_end) = out_edges(*vi, g); ei != ei_end; ++ei) {
        num_adjacent++;
      }
      if (num_adjacent % 2 == 1) {
        start_vertex = *vi;
      }
    }
  }

  std::set<Edge> visited_edges;
  std::vector<Vertex> tmp;
  std::vector<Vertex> order;
  tmp.push_back(start_vertex);
  while (!tmp.empty()) {
    Vertex v = tmp.back();
    typename graph_traits<Graph>::out_edge_iterator edgei, edgei_end;
    bool has_available_edge = false;
    for (tie(edgei, edgei_end) = out_edges(v, g); edgei != edgei_end; ++edgei) {
      if (visited_edges.find(*edgei) == visited_edges.end()) { //unmarked
        has_available_edge = true;
        Edge e = *edgei;
        Edge opposite_edge = edge(target(e, g), source(e, g), g).first;
        visited_edges.insert(e);
        visited_edges.insert(opposite_edge);

        Vertex neighbor = target(*edgei, g);
        tmp.push_back(neighbor);
        break;
      }
    }
    if (!has_available_edge) {
      if (!order.empty()) {
        Edge e;
        bool exists;
        tie(e, exists) = edge(order.back(), v, g);
        if (!exists) { throw "Error! Tried to use an edge that doesn't exist!"; }
        path.push_back(e);
        order.pop_back();
      }
      order.push_back(v);
      tmp.pop_back();
    }
  }
}

template <typename Graph>
bool
has_euler_path(const Graph& G) {
  std::vector<int> counts = get_graph_counts(G);
  return counts[1] == 1 && (counts[0] == 0 || counts[0] == 2);
}

template <typename Graph>
bool
has_euler_circuit(const Graph& G) {
  std::vector<int> counts = get_graph_counts(G);
  return counts[1] == 1 && counts[0] == 0;
}

template <typename Graph, typename Edge = typename graph_traits<Graph>::edge_descriptor>
void
compute_euler_circuit(const Graph& g, std::vector<Edge>& path) {
  if (has_euler_circuit(g)) {
    compute_euler(g, path, true);
  }
}

template <typename Graph, typename Edge = typename graph_traits<Graph>::edge_descriptor>
void
compute_euler_path(const Graph& g, std::vector<Edge>& path) {
  if (has_euler_path(g)) {
    compute_euler(g, path, false);
  }
}
